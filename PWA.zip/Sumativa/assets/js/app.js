if ( navigator.serviceWorker ) {

    navigator.serviceWorker.register( '../../SW.js' );

}