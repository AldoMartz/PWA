self.addEventListener("install", (a) => {
    const cacheStatic = caches
    .open(STATIC_CACHE)
    .then((cache) => cache.addAll(APP_SHELL));
    e.waitUntil(cacheStatic);
});

self.addEventListener("fetch", (a) => {
    console.log("fetch!", a.request);
    a.respondWith(
        caches
        .match(a.request)
        .then((res) => {
            return res || fetch(a.request);
        })
        .catch(console.Log)
    )
})